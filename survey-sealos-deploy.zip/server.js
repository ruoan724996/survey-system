const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const https = require('https');

const app = express();
const PORT = process.env.PORT || 3000;

// 飞书 API 配置
const FEISHU_CONFIG = {
  appId: 'cli_a90981de3c78dcc8',
  appSecret: 'RQ0RCFDrxfIelhQvgzHLJbp7C3agHnaq',
  appToken: 'MMwsb70JkaDngbs8P5ecXGllnse',
  tableId: 'tblWbQxbHNiKk5gB'
};

// Token 缓存
let cachedToken = null;
let tokenExpireTime = 0;

// 获取飞书 Token
async function getFeishuToken() {
  if (cachedToken && Date.now() < tokenExpireTime) {
    return cachedToken;
  }
  
  return new Promise((resolve, reject) => {
    const data = JSON.stringify({
      app_id: FEISHU_CONFIG.appId,
      app_secret: FEISHU_CONFIG.appSecret
    });
    
    const req = https.request(
      'https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal',
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(data)
        }
      },
      (res) => {
        let responseData = '';
        res.on('data', chunk => responseData += chunk);
        res.on('end', () => {
          try {
            const result = JSON.parse(responseData);
            if (result.code === 0) {
              cachedToken = result.tenant_access_token;
              tokenExpireTime = Date.now() + (result.expire - 300) * 1000;
              console.log('✅ Token 获取成功');
              resolve(cachedToken);
            } else {
              console.error('❌ Token 获取失败:', result.msg);
              reject(new Error(result.msg));
            }
          } catch (e) {
            reject(new Error('解析失败：' + e.message));
          }
        });
      }
    );
    
    req.on('error', reject);
    req.write(data);
    req.end();
  });
}

// 中间件
app.use(cors());
app.use(bodyParser.json({ limit: '10mb' }));
app.use(express.static('static'));

// 健康检查
app.get('/api/health', (req, res) => {
  res.json({ success: true, message: '服务正常' });
});

// 提交问卷
app.post('/api/submit', async (req, res) => {
  console.log('📝 收到问卷提交');
  
  try {
    const token = await getFeishuToken();
    const fields = { ...req.body };
    
    // 处理空值
    if (!fields['姓名'] || fields['姓名'].trim() === '') {
      fields['姓名'] = '匿名';
    }
    if (!fields['部门'] || fields['部门'].trim() === '') {
      fields['部门'] = '未填写';
    }
    
    const data = JSON.stringify({ fields });
    
    const httpsReq = https.request(
      `https://open.feishu.cn/open-apis/bitable/v1/apps/${FEISHU_CONFIG.appToken}/tables/${FEISHU_CONFIG.tableId}/records`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(data)
        }
      },
      (res) => {
        let responseData = '';
        res.on('data', chunk => responseData += chunk);
        res.on('end', () => {
          try {
            const result = JSON.parse(responseData);
            if (result.code === 0) {
              console.log('✅ 提交成功:', result.data.record.id);
              res.json({ success: true, recordId: result.data.record.id });
            } else {
              console.error('❌ 飞书 API 错误:', result.msg);
              res.status(500).json({ success: false, message: result.msg });
            }
          } catch (e) {
            console.error('❌ 解析失败:', e.message);
            res.status(500).json({ success: false, message: '解析失败：' + e.message });
          }
        });
      }
    );
    
    httpsReq.on('error', (e) => {
      console.error('❌ 请求失败:', e.message);
      res.status(500).json({ success: false, message: '请求失败：' + e.message });
    });
    
    httpsReq.write(data);
    httpsReq.end();
    
  } catch (error) {
    console.error('❌ 提交失败:', error.message);
    res.status(500).json({ success: false, message: error.message });
  }
});

// 启动服务
app.listen(PORT, () => {
  console.log('🚀 服务已启动');
  console.log(`📍 端口：${PORT}`);
  console.log(`🌐 访问：http://localhost:${PORT}/survey_form.html`);
});
